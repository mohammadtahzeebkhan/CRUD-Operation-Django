from django import forms
from django.db.models import fields
from .models import User
class studentRegistration(forms.ModelForm):
    class Meta:
        model=User
        fields=['name','email','rollno']